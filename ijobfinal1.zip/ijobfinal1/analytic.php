<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
<head>
	<script language="JavaScript" src="myIJob.js" type="text/javascript">
	</script>
	<link rel="stylesheet" type="text/css" href="newjobstyle.css" />
	<title>
		 job analytic
	</title>
</head>
<body>
<ul>
<li onclick="newAJob()">ByLocation</li>
<li onclick="newAJob()">ByPostion</li>
<li onclick="newAJob()">BySkill</li>
</ul>
</body>
</html>