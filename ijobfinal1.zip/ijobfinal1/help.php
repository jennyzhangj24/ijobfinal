<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
<head>
	<link rel="stylesheet" type="text/css" href="newjobstyle.css" />
	<title>
		New job form
	</title>
</head>
<body>
	<section id="form">
		<form name="form" method="post" action="register_finish.php">
		<li>username:<input type="text" name="id" /> </li>
		<li>password:<input type="password" name="pw" /> </li>
		<li>password again:<input type="password" name="pw2" /></li>
		<li>telephone:<input type="text" name="telephone" /></li>
		<li>address:<input type="text" name="address" /></li>
		<li>others:<textarea name="other" cols="45" rows="5"></textarea></li>
		<input type="submit" name="button" value="submit" />
		</form>
    </section>
</body>
</html>