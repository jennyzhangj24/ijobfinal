function newAJob(){
	window.open('newjob.html');
}