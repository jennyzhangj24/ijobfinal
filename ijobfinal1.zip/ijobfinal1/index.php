<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<script language="JavaScript" src="myIJob.js" type="text/javascript">
	</script>
	<link rel="stylesheet" type="text/css" href="ijobstyle.css" />
	<title>
		ijob
	</title>
</head>
<body>
<div id="header">
	<div id="topleft">
		<img src="logo.jpg" width=90% height=90% /></tr>
	</div>
	<div id="topmiddle">
		<p id="sentence"> Where there is a will, there is a way.</p>
	</div>

	<div class="loginform" id="form">  
		<form name="form" method="post" action="connect.php">
			<li>username:<input type="text" name="id" /> <br>
			<li>password:<input type="password" name="pw" /> <br>
			<input type="submit" name="button" value="log in" />&nbsp;&nbsp;
			<a href="register.php">Sign up</a>
		</form> 
	</div>
</div>
</body>	
</html>